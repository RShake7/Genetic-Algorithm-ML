using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public GeneticData GeneData;
    public GameObject RayPoint;
    
    public GameObject SpawnPoint;
    public  float DistFromSP;

    public GameObject EndPoint;
    public float DistFromEP;

    public GameObject EndPanel;

    bool CanMove;
    bool WallVisible;

    public void Intitialise()
    {
        GeneData = new GeneticData();
    }

    private void Update()
    {
        Ray();
        DistFromSP = Vector3.Distance(transform.position, SpawnPoint.transform.position);
        DistFromEP = Vector3.Distance(transform.position, EndPoint.transform.position);
    }

    public void Ray()
    {
        WallVisible = false;
        CanMove = true;
        RaycastHit hit;
        Debug.DrawRay(RayPoint.transform.position, RayPoint.transform.forward * 1, Color.red);
        if(Physics.SphereCast(RayPoint.transform.position, 0.2f, RayPoint.transform.forward, out hit, 1f))
        {
            if (hit.collider.gameObject.CompareTag("Wall"))
            {
                WallVisible = true;
                CanMove = false;
            }
        }
    }

    private void FixedUpdate()
    {
        transform.Rotate(0, GeneData.Genes[WallVisible], 0);
        if (CanMove)
        {
            transform.Translate(0, 0, 0.1f); 
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "End")
        {
            Time.timeScale = 0;
            EndPanel.SetActive(true);
        }
    }
    public void ContinueBut()
    {
        Time.timeScale = 10;
        EndPanel.SetActive(false);
    }
    public void QuitBut()
    {
        Application.Quit();
    }
}
