using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
public class Spawn : MonoBehaviour
{
    public GameObject AgentPrefab;
    public GameObject SpawnAgent;
    public GameObject StartingPos;
    public Text TimeText;
    public Text GenText;

    public int PopulationSize = 10;

    public static float timeElapsed = 0;
    public float TotalTime;
    public float timeScale;
    List<GameObject> Population = new List<GameObject>();
    int Generation = 0;

    List<GameObject> SortedAgents;
    public void Start()
    {
        SpawnObject();
    }

    public void Update()
    {
        TimeText.text = timeElapsed.ToString();
        GenText.text = Generation.ToString();
        timeElapsed += Time.deltaTime;
        if (timeElapsed >= TotalTime)
        {
            CreateNewPop();
            timeElapsed = 0;
            print("Break");
        }
    }
    void SpawnObject()
    {
        for (int i = 0; i < PopulationSize; i++)
        {
            SpawnAgent = Instantiate(AgentPrefab, StartingPos.transform.position, StartingPos.transform.rotation);
            SpawnAgent.GetComponent<Movement>().Intitialise();
            Population.Add(SpawnAgent);
        }
        Time.timeScale = timeScale;
    }

    GameObject CrossGene(GameObject ParentA, GameObject ParentB)
    {
        GameObject Child = Instantiate(AgentPrefab, StartingPos.transform.position, StartingPos.transform.rotation);
        Movement NewChild = Child.GetComponent<Movement>();

        if(Random.Range(0, 100) == 1)
        {
            NewChild.Intitialise();
        }
        else
        {
            NewChild.Intitialise();
            NewChild.GeneData.CrossData(ParentA.GetComponent<Movement>().GeneData, ParentB.GetComponent<Movement>().GeneData);
        }
        return Child;
    }

    public void CreateNewPop()
    {
        List<GameObject> SPSortedAgents = Population.OrderByDescending(o => o.GetComponent<Movement>().DistFromSP).ToList();
        List<GameObject> EPSortedAgents = Population.OrderBy(o => o.GetComponent<Movement>().DistFromEP).ToList();
        for (int i = 0; i < SPSortedAgents.Count; i++)
        {
            for (int j = 0; j < EPSortedAgents.Count; j++)
            {
                if (SPSortedAgents[i] == EPSortedAgents[i])
                {
                    SortedAgents = SPSortedAgents;
                }
                else
                {
                    SortedAgents = EPSortedAgents;
                }
            }
        }

        string DistanceCovered = "Gen:" + Generation;
        foreach(GameObject g in SortedAgents)
        {
            DistanceCovered += "," + g.GetComponent<Movement>().DistFromSP;
        }
        print("Dist:" + DistanceCovered);
        Population.Clear();
        print("P" + Population.Count);
        print("PS" + Population.Count);
        while (Population.Count < PopulationSize)
        {
            int TopParents = SortedAgents.Count / 4;
            Debug.Log(TopParents);
            for (int i = 0; i < TopParents - 1; i++)
            {
                for (int j = 1; j < TopParents; j++)
                {
                    Population.Add(CrossGene(SortedAgents[i], SortedAgents[j]));
                    if (Population.Count == PopulationSize)
                    {
                        break;
                    }
                    Population.Add(CrossGene(SortedAgents[j], SortedAgents[i]));
                    if (Population.Count == PopulationSize)
                    {
                        break;
                    }
                }
                if (Population.Count == PopulationSize)
                {
                    break;
                }
            }
        }
        for (int i = 0; i < SortedAgents.Count; i++)
        {
            Destroy(SortedAgents[i]);
        }
        Generation++;
    }
/*
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Wall")
        {
            Destroy(SpawnAgent);
            SpawnObject();
        }
    }*/
}
