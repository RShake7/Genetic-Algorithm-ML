using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GeneticData
{
    public Dictionary<bool, float> Genes;
    int DataLength;

    public GeneticData()
    {
        Genes = new Dictionary<bool, float>();
        RandomData();
    }

    public void RandomData()
    {
        Genes.Clear();
        Genes.Add(false, Random.Range(-90, 91));
        Genes.Add(true, Random.Range(-90, 91));
        DataLength = Genes.Count;
    }

    public void CrossData(GeneticData ChromosomeA, GeneticData ChromosomeB)
    {
        int i = 0;
        Dictionary<bool, float> NewGenes = new Dictionary<bool, float>();
        foreach (KeyValuePair<bool, float> Genome in Genes)
        {
            if (i < DataLength / 2)
            {
                NewGenes.Add(Genome.Key, ChromosomeA.Genes[Genome.Key]);
            }
            else
            {
                NewGenes.Add(Genome.Key, ChromosomeB.Genes[Genome.Key]);
            }
            i++;
        }
        Genes = NewGenes;
    }

    public float GetGene(bool Forward)
    {
        return Genes[Forward];
    }
}
